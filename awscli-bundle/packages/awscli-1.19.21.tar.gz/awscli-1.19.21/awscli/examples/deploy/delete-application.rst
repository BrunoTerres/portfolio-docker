**To delete an application**

The following ``delete-application`` example deletes the specified application that is associated with the user's AWS account. ::

    aws deploy delete-application --application-name WordPress_App

This command produces no output.