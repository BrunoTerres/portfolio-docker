# Botocore Documentation

Documentation for botocore can be found [here](https://botocore.amazonaws.com/v1/documentation/api/latest/index.html)
